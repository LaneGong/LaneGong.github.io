#!/usr/bin/env python3

import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('127.0.0.1', 9999))
print(s.recv(1024).decode('utf-8'))
flag=0

while True:
	name=input("请输入用户名(/exit)：")
	if not name:
		print("用户名不能为空！")
		continue
	s.send(name.encode())
	if name=='exit':
		break
	password=input("请输入登录密码：")
	if not password:
		print("用户名或密码不能为空！")
		continue
	s.send(password.encode())
	message=s.recv(1024).decode('utf-8')
	if message=='Failure!':
		print('用户名或密码不正确，请重新登陆！')
		continue
	else:
		print(message)
		flag=1
		break

if flag==1:
	while True:
		content=input('请输入你要询问的问题：')
		s.send(content.encode())
		reply=s.recv(1024).decode('utf-8')
		print(reply)
		if reply=='Unaccepted!Connection Refused!':
			break
		print('解答：'+s.recv(1024).decode('utf-8'))
		status=int(input("是否需要继续提问？(0-否，1-是)："))
		if status==1:
			s.send(b'continue')
			continue
		else:
			s.send(b'exit')
			break
s.close()
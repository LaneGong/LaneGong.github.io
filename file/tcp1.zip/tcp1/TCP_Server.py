#!/usr/bin/env python3

import socket
import threading
#线程模块，每个连接都必须创建新线程（或进程）来处理，否则，单线程在处理连接的过程中，无法接受其他客户端的连接
import time

def tcplink(sock,addr):
	print('\nAccept new connection from %s:%s...'%addr)
	sock.send(b'Welcome!')
	while True:
		name=sock.recv(1024)
		if name.decode('utf-8')=='exit':
			break
		password=sock.recv(1024)
		time.sleep(1)
		print("--%s:%s的登陆信息--"%addr)
		print("用户名:%s"%name.decode('utf-8'))
		print("密码：%s"%password.decode('utf-8'))
		n=int(input("登陆是否合法(0-否，1-是)："))
		if n==1:
			sock.send(('Hello,%s!'%name.decode('utf-8')).encode('utf-8'))
			while True:
				print('所提问题是：'+sock.recv(1024).decode('utf-8'))
				judge=int(input('问题是否合规(0-否，1-是)：'))
				if judge==1:
					sock.send('Problem is accpeted！Waiting...'.encode('utf-8'))
					answer=input('解答：')
					sock.send(answer.encode('utf-8'))
				else:
					sock.send('Unaccepted!Connection Refused!'.encode('utf-8'))
					break
				flag=sock.recv(1024).decode('utf-8')
				if flag=='exit':
					break
			break
		else:
			sock.send(b'Failure!')
	sock.close()
	print('Connection from %s:%s closed.'%addr)


#创建基于IPv4和TCP协议的Socket
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
#绑定监听的地址和端口
s.bind(('127.0.0.1',9999))#本机地址，外部计算机不可连
s.listen(5)#开始监听，参数用来指定等待连接的最大数量
print('Waiting for connection...')

#通过永久循环来接受来自客户端的连接
while True:
	sock,addr=s.accept()#accept()函数会等待并返回一个客户端的连接
	t=threading.Thread(target=tcplink,args=(sock,addr))#创建新线程
	#target->线程函数,args->传递给线程函数的参数，必须是tuple类型
	t.start()#启用线程活动
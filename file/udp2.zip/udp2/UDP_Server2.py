#!/usr/bin/env python3

import socket
import os
import threading

# 处理客户端请求的函数
def doRequest():
	while True:
		#接收来自客户端的消息
		msg,addr = server.recvfrom(1024)
		msglist = msg.decode().split(' ')  # 拆分数据,以空格为分隔
		if msglist[0] == 'login':#登陆
			Login(msglist[1], msglist[2],addr)
		elif msglist[0] == 'file':
			FileTrans(msglist[1],addr)
		elif msglist[0] == 'quit':
			print('-----%s:%s断开连接-----'%addr)

def Login(name,password,addr):
	try:
		if userlist[name]==password:
			server.sendto('OK'.encode(), addr)
			return
		else:
			server.sendto('Password is error!'.encode(), addr)
			return
	except KeyError:
		print('-- 登录信息 --')
		print('Username:'+name)
		print('Password:'+password)
		confirm=int(input("登陆是否合法(1-yes,2-no)："))
		if confirm==1:
			server.sendto('OK'.encode(), addr)
			userlist[name]=password
			print(userlist)
		else:
			server.sendto('Login Error!'.encode(), addr)

def FileTrans(size,addr):
	count=0
	while True:
		if count == 0:
			name,addr=server.recvfrom(1024)#返回数据和客户端的地址与端口
			print('Received from %s:%s.'%addr)
			f=open(name, 'wb')
		data,addr = server.recvfrom(1024)
		if str(data) != "b'end'":
			f.write(data)
		else:
			break
		count+=1
	f.close()
	if str(os.path.getsize(name.decode('utf-8')))==size:
		server.sendto(b'File is accepted correctly!',addr)
		print('recircled:'+str(count)+'次')
	else:
		server.sendto(b'Content is lost!',addr)
			

# 创建 UDP 套接字
server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # 绑定地址
address = ('127.0.0.1',9999)
server.bind(address)
userlist = {}  # 此字典用于存放客户端的名字和密码、地址
print('Bind UDP on 9999...')
# 创建多线程
t = threading.Thread(target=doRequest(), args=(server,))
t.start()

#!/usr/bin/env python3

import socket
import os
import time


address = ('127.0.0.1', 9999)
# 创建 UDP 套接字
client=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

while True:
	name = input('请输入用户名：')
	password=input('请输入密码：')
	message = 'login ' + name + ' ' + password
	client.sendto(message.encode(), address)
	data, addr = client.recvfrom(1024)
	if data.decode() == 'OK':
		print('登录成功\nHello %s!'%name)
		break
	else: 
		print(data.decode())
	
	
# 文件传送交互
while True:
	file = input('please enter the filename you want to send:\n')
	filesize = str(os.path.getsize(file))
	filepath,filename=os.path.split(file)
	filemsg='file '+filesize
	client.sendto(filemsg.encode(),address)
	f=open(file,'rb')
	count = 0
	while True:
		if count == 0:
			data = bytes(filename, encoding = "utf-8")
			start = time.time()
			client.sendto(data,address)
		data = f.read(1024)
		if str(data) != "b''":
			client.sendto(data,address)
		else:
			client.sendto('end'.encode('utf-8'),address)
			break
		count+=1
		
	print('recircled:'+str(count)+'次')
	end = time.time()
	print('cost'+' '+str(round(end-start,2))+'s')
	print(client.recv(1024).decode('utf-8'))
	choice=int(input("是否继续发送或退出？(1-yes,2-no):"))
	if choice==1:
		continue
	else:
		client.sendto(b'quit',address)
		break

# 关闭连接
print('-'*5+'服务器断开连接'+'-'*5)
client.close()
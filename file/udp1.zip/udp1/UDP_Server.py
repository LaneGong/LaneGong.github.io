#!/usr/bin/env python3

import socket
import time
import os


s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)#创建基于IPv4和UDP协议的Socket
#绑定端口
s.bind(('127.0.0.1',9999))
#udp不需要调用listen()方法而是直接接收来自任何客户端的数据
print('Bind UDP on 9999...')
#通过永久循环来接受来自客户端的连接

while True:
	count=0
	while True:
		if count == 0:
			name,addr=s.recvfrom(1024)#返回数据和客户端的地址与端口
			size,addr=s.recvfrom(1024)
			print('Received from %s:%s.'%addr)
			f=open(name, 'wb')
		data,addr = s.recvfrom(1024)
		if str(data) != "b'end'":
			f.write(data)
		else:
			break
		count+=1
		
	f.close()
	if str(os.path.getsize(name.decode('utf-8')))==size.decode('utf-8'):
		s.sendto(b'File is accepted correctly!',addr)
		print('recircled:'+str(count)+'次')
	else:
		s.sendto(b'Content is lost!',addr)

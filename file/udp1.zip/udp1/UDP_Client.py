#!/usr/bin/env python3

import socket
import os
import time

s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
while True:
	file = input('please enter the filename you want to send:\n')
	filesize = str(os.path.getsize(file))
	filepath,filename=os.path.split(file)
	server_address=('127.0.0.1',9999)
	f=open(file,'rb')
	
	count = 0
	while True:
		if count == 0:
			data = bytes(filename, encoding = "utf-8")
			start = time.time()
			s.sendto(data,server_address)
			s.sendto(filesize.encode(),server_address)
		data = f.read(1024)
		if str(data) != "b''":
			s.sendto(data,server_address)
		else:
			s.sendto('end'.encode('utf-8'),server_address)
			break
		count+=1
	
	print('recircled:'+str(count)+'次')
	end = time.time()
	print('cost'+' '+str(round(end-start,2))+'s')
	print(s.recv(1024).decode('utf-8'))
	choice=int(input("是否继续发送或退出？(0-退出，1-继续):"))
	if choice==1:
		continue
	else:
		print("Exit!")
		break
s.close()

#name=input("请输入用户名：")
#if not name:
#	print("用户名不能为空！")
#s.sendto(name.encode(),('127.0.0.1',9999))
#password=input("请输入登录密码：")
#if not password:
#	print("用户名或密码不能为空！")
#s.sendto(password.encode(),('127.0.0.1',9999))